﻿
namespace Car_Rental_Agency
{
    partial class CustomerLogin
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.loginBtn = new System.Windows.Forms.Button();
            this.loginpasswordTbox = new System.Windows.Forms.TextBox();
            this.loginemailTextBox = new System.Windows.Forms.TextBox();
            this.customerEmail = new System.Windows.Forms.Label();
            this.Cpsswd = new System.Windows.Forms.Label();
            this.SignUp = new System.Windows.Forms.GroupBox();
            this.label7 = new System.Windows.Forms.Label();
            this.agedateTimePicker = new System.Windows.Forms.DateTimePicker();
            this.dlisenceTextBox = new System.Windows.Forms.TextBox();
            this.dlisenceType = new System.Windows.Forms.Label();
            this.signupBtn = new System.Windows.Forms.Button();
            this.DriLisence = new System.Windows.Forms.TextBox();
            this.dlisence = new System.Windows.Forms.Label();
            this.ConfirmPsswdTextBox = new System.Windows.Forms.TextBox();
            this.psswdTextBox = new System.Windows.Forms.TextBox();
            this.postalcode = new System.Windows.Forms.TextBox();
            this.country = new System.Windows.Forms.TextBox();
            this.state = new System.Windows.Forms.TextBox();
            this.city = new System.Windows.Forms.TextBox();
            this.street = new System.Windows.Forms.TextBox();
            this.phone = new System.Windows.Forms.TextBox();
            this.ConPsswd = new System.Windows.Forms.Label();
            this.password = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.emailTextBox = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.lName = new System.Windows.Forms.TextBox();
            this.fName = new System.Windows.Forms.TextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.groupBox1.SuspendLayout();
            this.SignUp.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.loginBtn);
            this.groupBox1.Controls.Add(this.loginpasswordTbox);
            this.groupBox1.Controls.Add(this.loginemailTextBox);
            this.groupBox1.Controls.Add(this.customerEmail);
            this.groupBox1.Controls.Add(this.Cpsswd);
            this.groupBox1.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.ForeColor = System.Drawing.Color.White;
            this.groupBox1.Location = new System.Drawing.Point(12, 94);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(288, 307);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Sign In";
            // 
            // loginBtn
            // 
            this.loginBtn.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.loginBtn.ForeColor = System.Drawing.Color.Black;
            this.loginBtn.Location = new System.Drawing.Point(56, 221);
            this.loginBtn.Name = "loginBtn";
            this.loginBtn.Size = new System.Drawing.Size(150, 41);
            this.loginBtn.TabIndex = 33;
            this.loginBtn.Text = "Login";
            this.loginBtn.UseVisualStyleBackColor = false;
            this.loginBtn.Click += new System.EventHandler(this.loginBtn_Click);
            // 
            // loginpasswordTbox
            // 
            this.loginpasswordTbox.Location = new System.Drawing.Point(21, 161);
            this.loginpasswordTbox.Multiline = true;
            this.loginpasswordTbox.Name = "loginpasswordTbox";
            this.loginpasswordTbox.Size = new System.Drawing.Size(244, 26);
            this.loginpasswordTbox.TabIndex = 4;
            // 
            // loginemailTextBox
            // 
            this.loginemailTextBox.Location = new System.Drawing.Point(21, 71);
            this.loginemailTextBox.Multiline = true;
            this.loginemailTextBox.Name = "loginemailTextBox";
            this.loginemailTextBox.Size = new System.Drawing.Size(244, 26);
            this.loginemailTextBox.TabIndex = 3;
            // 
            // customerEmail
            // 
            this.customerEmail.AutoSize = true;
            this.customerEmail.BackColor = System.Drawing.Color.DarkOrange;
            this.customerEmail.Location = new System.Drawing.Point(17, 39);
            this.customerEmail.Name = "customerEmail";
            this.customerEmail.Size = new System.Drawing.Size(51, 19);
            this.customerEmail.TabIndex = 1;
            this.customerEmail.Text = "Email";
            this.customerEmail.Click += new System.EventHandler(this.label1_Click);
            // 
            // Cpsswd
            // 
            this.Cpsswd.AutoSize = true;
            this.Cpsswd.BackColor = System.Drawing.Color.DarkOrange;
            this.Cpsswd.Location = new System.Drawing.Point(17, 129);
            this.Cpsswd.Name = "Cpsswd";
            this.Cpsswd.Size = new System.Drawing.Size(86, 19);
            this.Cpsswd.TabIndex = 2;
            this.Cpsswd.Text = "Password";
            this.Cpsswd.Click += new System.EventHandler(this.label2_Click);
            // 
            // SignUp
            // 
            this.SignUp.Controls.Add(this.label7);
            this.SignUp.Controls.Add(this.agedateTimePicker);
            this.SignUp.Controls.Add(this.dlisenceTextBox);
            this.SignUp.Controls.Add(this.dlisenceType);
            this.SignUp.Controls.Add(this.signupBtn);
            this.SignUp.Controls.Add(this.DriLisence);
            this.SignUp.Controls.Add(this.dlisence);
            this.SignUp.Controls.Add(this.ConfirmPsswdTextBox);
            this.SignUp.Controls.Add(this.psswdTextBox);
            this.SignUp.Controls.Add(this.postalcode);
            this.SignUp.Controls.Add(this.country);
            this.SignUp.Controls.Add(this.state);
            this.SignUp.Controls.Add(this.city);
            this.SignUp.Controls.Add(this.street);
            this.SignUp.Controls.Add(this.phone);
            this.SignUp.Controls.Add(this.ConPsswd);
            this.SignUp.Controls.Add(this.password);
            this.SignUp.Controls.Add(this.label10);
            this.SignUp.Controls.Add(this.label11);
            this.SignUp.Controls.Add(this.label12);
            this.SignUp.Controls.Add(this.label6);
            this.SignUp.Controls.Add(this.label5);
            this.SignUp.Controls.Add(this.label4);
            this.SignUp.Controls.Add(this.emailTextBox);
            this.SignUp.Controls.Add(this.label3);
            this.SignUp.Controls.Add(this.label2);
            this.SignUp.Controls.Add(this.label1);
            this.SignUp.Controls.Add(this.lName);
            this.SignUp.Controls.Add(this.fName);
            this.SignUp.Font = new System.Drawing.Font("Arial", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SignUp.ForeColor = System.Drawing.Color.White;
            this.SignUp.Location = new System.Drawing.Point(331, 94);
            this.SignUp.Name = "SignUp";
            this.SignUp.Size = new System.Drawing.Size(730, 478);
            this.SignUp.TabIndex = 1;
            this.SignUp.TabStop = false;
            this.SignUp.Text = "Sign Up";
            this.SignUp.Enter += new System.EventHandler(this.SignUp_Enter);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.BackColor = System.Drawing.Color.Black;
            this.label7.Location = new System.Drawing.Point(235, 329);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(89, 22);
            this.label7.TabIndex = 36;
            this.label7.Text = "Birthday";
            // 
            // agedateTimePicker
            // 
            this.agedateTimePicker.Location = new System.Drawing.Point(239, 360);
            this.agedateTimePicker.Name = "agedateTimePicker";
            this.agedateTimePicker.Size = new System.Drawing.Size(238, 29);
            this.agedateTimePicker.TabIndex = 35;
            // 
            // dlisenceTextBox
            // 
            this.dlisenceTextBox.Location = new System.Drawing.Point(16, 362);
            this.dlisenceTextBox.Multiline = true;
            this.dlisenceTextBox.Name = "dlisenceTextBox";
            this.dlisenceTextBox.Size = new System.Drawing.Size(190, 27);
            this.dlisenceTextBox.TabIndex = 34;
            // 
            // dlisenceType
            // 
            this.dlisenceType.AutoSize = true;
            this.dlisenceType.BackColor = System.Drawing.Color.Black;
            this.dlisenceType.Location = new System.Drawing.Point(12, 329);
            this.dlisenceType.Name = "dlisenceType";
            this.dlisenceType.Size = new System.Drawing.Size(206, 22);
            this.dlisenceType.TabIndex = 33;
            this.dlisenceType.Text = "Driving Lisence Type";
            // 
            // signupBtn
            // 
            this.signupBtn.BackColor = System.Drawing.Color.Gray;
            this.signupBtn.ForeColor = System.Drawing.Color.Black;
            this.signupBtn.Location = new System.Drawing.Point(283, 416);
            this.signupBtn.Name = "signupBtn";
            this.signupBtn.Size = new System.Drawing.Size(150, 41);
            this.signupBtn.TabIndex = 32;
            this.signupBtn.Text = "Sign Up!";
            this.signupBtn.UseVisualStyleBackColor = false;
            this.signupBtn.Click += new System.EventHandler(this.button1_Click);
            // 
            // DriLisence
            // 
            this.DriLisence.Location = new System.Drawing.Point(16, 284);
            this.DriLisence.Multiline = true;
            this.DriLisence.Name = "DriLisence";
            this.DriLisence.Size = new System.Drawing.Size(190, 27);
            this.DriLisence.TabIndex = 31;
            // 
            // dlisence
            // 
            this.dlisence.AutoSize = true;
            this.dlisence.BackColor = System.Drawing.Color.Black;
            this.dlisence.Location = new System.Drawing.Point(12, 247);
            this.dlisence.Name = "dlisence";
            this.dlisence.Size = new System.Drawing.Size(190, 22);
            this.dlisence.TabIndex = 30;
            this.dlisence.Text = "Driving Lisence No.";
            // 
            // ConfirmPsswdTextBox
            // 
            this.ConfirmPsswdTextBox.Location = new System.Drawing.Point(473, 284);
            this.ConfirmPsswdTextBox.Multiline = true;
            this.ConfirmPsswdTextBox.Name = "ConfirmPsswdTextBox";
            this.ConfirmPsswdTextBox.Size = new System.Drawing.Size(190, 27);
            this.ConfirmPsswdTextBox.TabIndex = 29;
            // 
            // psswdTextBox
            // 
            this.psswdTextBox.Location = new System.Drawing.Point(243, 284);
            this.psswdTextBox.Multiline = true;
            this.psswdTextBox.Name = "psswdTextBox";
            this.psswdTextBox.Size = new System.Drawing.Size(190, 27);
            this.psswdTextBox.TabIndex = 28;
            // 
            // postalcode
            // 
            this.postalcode.Location = new System.Drawing.Point(473, 204);
            this.postalcode.Multiline = true;
            this.postalcode.Name = "postalcode";
            this.postalcode.Size = new System.Drawing.Size(190, 27);
            this.postalcode.TabIndex = 27;
            // 
            // country
            // 
            this.country.Location = new System.Drawing.Point(243, 205);
            this.country.Multiline = true;
            this.country.Name = "country";
            this.country.Size = new System.Drawing.Size(190, 27);
            this.country.TabIndex = 26;
            // 
            // state
            // 
            this.state.Location = new System.Drawing.Point(16, 205);
            this.state.Multiline = true;
            this.state.Name = "state";
            this.state.Size = new System.Drawing.Size(190, 27);
            this.state.TabIndex = 25;
            // 
            // city
            // 
            this.city.Location = new System.Drawing.Point(473, 132);
            this.city.Multiline = true;
            this.city.Name = "city";
            this.city.Size = new System.Drawing.Size(190, 27);
            this.city.TabIndex = 24;
            // 
            // street
            // 
            this.street.Location = new System.Drawing.Point(243, 136);
            this.street.Multiline = true;
            this.street.Name = "street";
            this.street.Size = new System.Drawing.Size(190, 27);
            this.street.TabIndex = 23;
            // 
            // phone
            // 
            this.phone.Location = new System.Drawing.Point(16, 136);
            this.phone.Multiline = true;
            this.phone.Name = "phone";
            this.phone.Size = new System.Drawing.Size(190, 27);
            this.phone.TabIndex = 22;
            // 
            // ConPsswd
            // 
            this.ConPsswd.AutoSize = true;
            this.ConPsswd.BackColor = System.Drawing.Color.Black;
            this.ConPsswd.Location = new System.Drawing.Point(469, 247);
            this.ConPsswd.Name = "ConPsswd";
            this.ConPsswd.Size = new System.Drawing.Size(182, 22);
            this.ConPsswd.TabIndex = 20;
            this.ConPsswd.Text = "Confirm Password";
            this.ConPsswd.Click += new System.EventHandler(this.label8_Click);
            // 
            // password
            // 
            this.password.AutoSize = true;
            this.password.BackColor = System.Drawing.Color.Black;
            this.password.Location = new System.Drawing.Point(243, 247);
            this.password.Name = "password";
            this.password.Size = new System.Drawing.Size(103, 22);
            this.password.TabIndex = 19;
            this.password.Text = "Password";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.BackColor = System.Drawing.Color.Black;
            this.label10.Location = new System.Drawing.Point(469, 179);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(122, 22);
            this.label10.TabIndex = 17;
            this.label10.Text = "Postal Code";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.BackColor = System.Drawing.Color.Black;
            this.label11.Location = new System.Drawing.Point(239, 179);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(85, 22);
            this.label11.TabIndex = 16;
            this.label11.Text = "Country";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.BackColor = System.Drawing.Color.Black;
            this.label12.Location = new System.Drawing.Point(12, 180);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(57, 22);
            this.label12.TabIndex = 15;
            this.label12.Text = "State";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.BackColor = System.Drawing.Color.Black;
            this.label6.Location = new System.Drawing.Point(469, 104);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(46, 22);
            this.label6.TabIndex = 12;
            this.label6.Text = "City";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.Color.Black;
            this.label5.Location = new System.Drawing.Point(239, 104);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(65, 22);
            this.label5.TabIndex = 11;
            this.label5.Text = "Street";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.Black;
            this.label4.Location = new System.Drawing.Point(12, 104);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(70, 22);
            this.label4.TabIndex = 10;
            this.label4.Text = "Phone";
            // 
            // emailTextBox
            // 
            this.emailTextBox.Location = new System.Drawing.Point(473, 65);
            this.emailTextBox.Multiline = true;
            this.emailTextBox.Name = "emailTextBox";
            this.emailTextBox.Size = new System.Drawing.Size(190, 27);
            this.emailTextBox.TabIndex = 9;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.Black;
            this.label3.Location = new System.Drawing.Point(469, 35);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(61, 22);
            this.label3.TabIndex = 8;
            this.label3.Text = "Email";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Black;
            this.label2.Location = new System.Drawing.Point(239, 35);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(107, 22);
            this.label2.TabIndex = 7;
            this.label2.Text = "Last Name";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Black;
            this.label1.Location = new System.Drawing.Point(12, 35);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(109, 22);
            this.label1.TabIndex = 6;
            this.label1.Text = "First Name";
            // 
            // lName
            // 
            this.lName.Location = new System.Drawing.Point(243, 65);
            this.lName.Multiline = true;
            this.lName.Name = "lName";
            this.lName.Size = new System.Drawing.Size(190, 27);
            this.lName.TabIndex = 5;
            this.lName.TextChanged += new System.EventHandler(this.textBox4_TextChanged);
            // 
            // fName
            // 
            this.fName.Location = new System.Drawing.Point(16, 65);
            this.fName.Multiline = true;
            this.fName.Name = "fName";
            this.fName.Size = new System.Drawing.Size(190, 27);
            this.fName.TabIndex = 4;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Arial Black", 26.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.Location = new System.Drawing.Point(266, 9);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(353, 50);
            this.label13.TabIndex = 2;
            this.label13.Text = "Login OR Sign Up";
            this.label13.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // CustomerLogin
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Black;
            this.ClientSize = new System.Drawing.Size(1073, 617);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.SignUp);
            this.Controls.Add(this.groupBox1);
            this.ForeColor = System.Drawing.Color.White;
            this.Name = "CustomerLogin";
            this.Text = "Login";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.SignUp.ResumeLayout(false);
            this.SignUp.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label customerEmail;
        private System.Windows.Forms.Label Cpsswd;
        private System.Windows.Forms.TextBox loginpasswordTbox;
        private System.Windows.Forms.TextBox loginemailTextBox;
        private System.Windows.Forms.GroupBox SignUp;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox lName;
        private System.Windows.Forms.TextBox fName;
        private System.Windows.Forms.TextBox city;
        private System.Windows.Forms.TextBox street;
        private System.Windows.Forms.TextBox phone;
        private System.Windows.Forms.Label ConPsswd;
        private System.Windows.Forms.Label password;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox emailTextBox;
        private System.Windows.Forms.TextBox ConfirmPsswdTextBox;
        private System.Windows.Forms.TextBox psswdTextBox;
        private System.Windows.Forms.TextBox postalcode;
        private System.Windows.Forms.TextBox country;
        private System.Windows.Forms.TextBox state;
        private System.Windows.Forms.TextBox DriLisence;
        private System.Windows.Forms.Label dlisence;
        private System.Windows.Forms.Button loginBtn;
        private System.Windows.Forms.Button signupBtn;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.TextBox dlisenceTextBox;
        private System.Windows.Forms.Label dlisenceType;
        private System.Windows.Forms.DateTimePicker agedateTimePicker;
        private System.Windows.Forms.Label label7;
    }
}