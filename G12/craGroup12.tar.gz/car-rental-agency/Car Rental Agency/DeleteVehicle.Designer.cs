﻿
namespace Car_Rental_Agency
{
    partial class DeleteVehicle
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.availabilityTextBox = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.vehicleTypeTextBox = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.currentBranchTB = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.milesTextBox = new System.Windows.Forms.TextBox();
            this.makeTextBox = new System.Windows.Forms.TextBox();
            this.button1 = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.seatsTextBox = new System.Windows.Forms.TextBox();
            this.modelTextBox = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.makeYearTextBox = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.queryResultLabel = new System.Windows.Forms.Label();
            this.VehicleinfodatagridView = new System.Windows.Forms.DataGridView();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.VehicleinfodatagridView)).BeginInit();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.label8);
            this.groupBox1.Controls.Add(this.label7);
            this.groupBox1.Controls.Add(this.label6);
            this.groupBox1.Controls.Add(this.availabilityTextBox);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.vehicleTypeTextBox);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.currentBranchTB);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.milesTextBox);
            this.groupBox1.Controls.Add(this.makeTextBox);
            this.groupBox1.Controls.Add(this.button1);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.seatsTextBox);
            this.groupBox1.Controls.Add(this.modelTextBox);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.makeYearTextBox);
            this.groupBox1.ForeColor = System.Drawing.Color.White;
            this.groupBox1.Location = new System.Drawing.Point(3, 79);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(423, 357);
            this.groupBox1.TabIndex = 46;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Select Vehicle to delete";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.ForeColor = System.Drawing.Color.DimGray;
            this.label8.Location = new System.Drawing.Point(6, 39);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(121, 19);
            this.label8.TabIndex = 30;
            this.label8.Text = "Curent Branch";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.Color.DimGray;
            this.label7.Location = new System.Drawing.Point(13, 276);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(90, 19);
            this.label7.TabIndex = 29;
            this.label7.Text = "Availability";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.DimGray;
            this.label6.Location = new System.Drawing.Point(13, 243);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(48, 19);
            this.label6.TabIndex = 28;
            this.label6.Text = "Miles";
            // 
            // availabilityTextBox
            // 
            this.availabilityTextBox.BackColor = System.Drawing.Color.Black;
            this.availabilityTextBox.ForeColor = System.Drawing.Color.White;
            this.availabilityTextBox.Location = new System.Drawing.Point(134, 278);
            this.availabilityTextBox.Multiline = true;
            this.availabilityTextBox.Name = "availabilityTextBox";
            this.availabilityTextBox.Size = new System.Drawing.Size(259, 27);
            this.availabilityTextBox.TabIndex = 39;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.DimGray;
            this.label5.Location = new System.Drawing.Point(11, 210);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(52, 19);
            this.label5.TabIndex = 27;
            this.label5.Text = "Seats";
            // 
            // vehicleTypeTextBox
            // 
            this.vehicleTypeTextBox.BackColor = System.Drawing.Color.Black;
            this.vehicleTypeTextBox.ForeColor = System.Drawing.Color.White;
            this.vehicleTypeTextBox.Location = new System.Drawing.Point(134, 78);
            this.vehicleTypeTextBox.Multiline = true;
            this.vehicleTypeTextBox.Name = "vehicleTypeTextBox";
            this.vehicleTypeTextBox.Size = new System.Drawing.Size(259, 27);
            this.vehicleTypeTextBox.TabIndex = 38;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.DimGray;
            this.label4.Location = new System.Drawing.Point(13, 177);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(42, 19);
            this.label4.TabIndex = 26;
            this.label4.Text = "Year";
            // 
            // currentBranchTB
            // 
            this.currentBranchTB.BackColor = System.Drawing.Color.Black;
            this.currentBranchTB.ForeColor = System.Drawing.Color.White;
            this.currentBranchTB.Location = new System.Drawing.Point(134, 40);
            this.currentBranchTB.Multiline = true;
            this.currentBranchTB.Name = "currentBranchTB";
            this.currentBranchTB.Size = new System.Drawing.Size(259, 27);
            this.currentBranchTB.TabIndex = 37;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.DimGray;
            this.label3.Location = new System.Drawing.Point(13, 144);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(55, 19);
            this.label3.TabIndex = 25;
            this.label3.Text = "Model";
            // 
            // milesTextBox
            // 
            this.milesTextBox.BackColor = System.Drawing.Color.Black;
            this.milesTextBox.ForeColor = System.Drawing.Color.White;
            this.milesTextBox.Location = new System.Drawing.Point(134, 241);
            this.milesTextBox.Multiline = true;
            this.milesTextBox.Name = "milesTextBox";
            this.milesTextBox.Size = new System.Drawing.Size(259, 27);
            this.milesTextBox.TabIndex = 35;
            // 
            // makeTextBox
            // 
            this.makeTextBox.BackColor = System.Drawing.Color.Black;
            this.makeTextBox.ForeColor = System.Drawing.Color.White;
            this.makeTextBox.Location = new System.Drawing.Point(134, 109);
            this.makeTextBox.Multiline = true;
            this.makeTextBox.Name = "makeTextBox";
            this.makeTextBox.Size = new System.Drawing.Size(259, 27);
            this.makeTextBox.TabIndex = 31;
            // 
            // button1
            // 
            this.button1.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.ForeColor = System.Drawing.Color.Black;
            this.button1.Location = new System.Drawing.Point(200, 321);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(98, 24);
            this.button1.TabIndex = 36;
            this.button1.Text = "Delete";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click_1);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.DimGray;
            this.label2.Location = new System.Drawing.Point(13, 111);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(49, 19);
            this.label2.TabIndex = 24;
            this.label2.Text = "Make";
            // 
            // seatsTextBox
            // 
            this.seatsTextBox.BackColor = System.Drawing.Color.Black;
            this.seatsTextBox.ForeColor = System.Drawing.Color.White;
            this.seatsTextBox.Location = new System.Drawing.Point(134, 208);
            this.seatsTextBox.Multiline = true;
            this.seatsTextBox.Name = "seatsTextBox";
            this.seatsTextBox.Size = new System.Drawing.Size(259, 27);
            this.seatsTextBox.TabIndex = 34;
            // 
            // modelTextBox
            // 
            this.modelTextBox.BackColor = System.Drawing.Color.Black;
            this.modelTextBox.ForeColor = System.Drawing.Color.White;
            this.modelTextBox.Location = new System.Drawing.Point(134, 142);
            this.modelTextBox.Multiline = true;
            this.modelTextBox.Name = "modelTextBox";
            this.modelTextBox.Size = new System.Drawing.Size(259, 27);
            this.modelTextBox.TabIndex = 32;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.DimGray;
            this.label1.Location = new System.Drawing.Point(11, 77);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(105, 19);
            this.label1.TabIndex = 23;
            this.label1.Text = "Vehicle Type";
            // 
            // makeYearTextBox
            // 
            this.makeYearTextBox.BackColor = System.Drawing.Color.Black;
            this.makeYearTextBox.ForeColor = System.Drawing.Color.White;
            this.makeYearTextBox.Location = new System.Drawing.Point(134, 175);
            this.makeYearTextBox.Multiline = true;
            this.makeYearTextBox.Name = "makeYearTextBox";
            this.makeYearTextBox.Size = new System.Drawing.Size(259, 27);
            this.makeYearTextBox.TabIndex = 33;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.BackColor = System.Drawing.Color.Black;
            this.label10.Font = new System.Drawing.Font("Arial", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.ForeColor = System.Drawing.Color.White;
            this.label10.Location = new System.Drawing.Point(387, 30);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(200, 32);
            this.label10.TabIndex = 45;
            this.label10.Text = "Delete Vehicle";
            // 
            // queryResultLabel
            // 
            this.queryResultLabel.AutoSize = true;
            this.queryResultLabel.Location = new System.Drawing.Point(200, 460);
            this.queryResultLabel.Name = "queryResultLabel";
            this.queryResultLabel.Size = new System.Drawing.Size(0, 13);
            this.queryResultLabel.TabIndex = 44;
            this.queryResultLabel.Click += new System.EventHandler(this.label9_Click_1);
            // 
            // VehicleinfodatagridView
            // 
            this.VehicleinfodatagridView.BackgroundColor = System.Drawing.Color.Black;
            this.VehicleinfodatagridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.VehicleinfodatagridView.Location = new System.Drawing.Point(443, 79);
            this.VehicleinfodatagridView.Name = "VehicleinfodatagridView";
            this.VehicleinfodatagridView.RowHeadersWidth = 62;
            this.VehicleinfodatagridView.Size = new System.Drawing.Size(637, 357);
            this.VehicleinfodatagridView.TabIndex = 43;
            this.VehicleinfodatagridView.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.VehicleinfodatagridView_CellContentClick);
            // 
            // DeleteVehicle
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Black;
            this.ClientSize = new System.Drawing.Size(956, 565);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.queryResultLabel);
            this.Controls.Add(this.VehicleinfodatagridView);
            this.ForeColor = System.Drawing.Color.DimGray;
            this.Name = "DeleteVehicle";
            this.Text = "DeleteVehicle";
            this.Load += new System.EventHandler(this.DeleteVehicle_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.VehicleinfodatagridView)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox availabilityTextBox;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox vehicleTypeTextBox;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox currentBranchTB;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox milesTextBox;
        private System.Windows.Forms.TextBox makeTextBox;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox seatsTextBox;
        private System.Windows.Forms.TextBox modelTextBox;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox makeYearTextBox;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label queryResultLabel;
        private System.Windows.Forms.DataGridView VehicleinfodatagridView;
    }
}