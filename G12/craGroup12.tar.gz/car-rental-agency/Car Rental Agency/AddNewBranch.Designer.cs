﻿
namespace Car_Rental_Agency
{
    partial class AddNewBranch
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.addBranchbutton = new System.Windows.Forms.Button();
            this.branchPhoneTextbox = new System.Windows.Forms.TextBox();
            this.branchPostalcodeTextbox = new System.Windows.Forms.TextBox();
            this.branchCountryTextbox = new System.Windows.Forms.TextBox();
            this.branchStateTextbox = new System.Windows.Forms.TextBox();
            this.branchCityTextbox = new System.Windows.Forms.TextBox();
            this.branchStreetTextbox = new System.Windows.Forms.TextBox();
            this.branchNameTextbox = new System.Windows.Forms.TextBox();
            this.branchstatelabel = new System.Windows.Forms.Label();
            this.branchphonelabel = new System.Windows.Forms.Label();
            this.branchpostalcodelabel = new System.Windows.Forms.Label();
            this.branchcountrylabel = new System.Windows.Forms.Label();
            this.branchcitylabel = new System.Windows.Forms.Label();
            this.branchstreetlabel = new System.Windows.Forms.Label();
            this.branchNamelabel = new System.Windows.Forms.Label();
            this.querylabel = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.addBranchbutton);
            this.groupBox1.Controls.Add(this.branchPhoneTextbox);
            this.groupBox1.Controls.Add(this.branchPostalcodeTextbox);
            this.groupBox1.Controls.Add(this.branchCountryTextbox);
            this.groupBox1.Controls.Add(this.branchStateTextbox);
            this.groupBox1.Controls.Add(this.branchCityTextbox);
            this.groupBox1.Controls.Add(this.branchStreetTextbox);
            this.groupBox1.Controls.Add(this.branchNameTextbox);
            this.groupBox1.Controls.Add(this.branchstatelabel);
            this.groupBox1.Controls.Add(this.branchphonelabel);
            this.groupBox1.Controls.Add(this.branchpostalcodelabel);
            this.groupBox1.Controls.Add(this.branchcountrylabel);
            this.groupBox1.Controls.Add(this.branchcitylabel);
            this.groupBox1.Controls.Add(this.branchstreetlabel);
            this.groupBox1.Controls.Add(this.branchNamelabel);
            this.groupBox1.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.ForeColor = System.Drawing.Color.White;
            this.groupBox1.Location = new System.Drawing.Point(152, 85);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(524, 355);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Branch";
            // 
            // addBranchbutton
            // 
            this.addBranchbutton.ForeColor = System.Drawing.Color.Black;
            this.addBranchbutton.Location = new System.Drawing.Point(213, 294);
            this.addBranchbutton.Name = "addBranchbutton";
            this.addBranchbutton.Size = new System.Drawing.Size(150, 32);
            this.addBranchbutton.TabIndex = 14;
            this.addBranchbutton.Text = "Add Branch";
            this.addBranchbutton.UseVisualStyleBackColor = true;
            // 
            // branchPhoneTextbox
            // 
            this.branchPhoneTextbox.BackColor = System.Drawing.Color.Black;
            this.branchPhoneTextbox.ForeColor = System.Drawing.Color.White;
            this.branchPhoneTextbox.Location = new System.Drawing.Point(167, 248);
            this.branchPhoneTextbox.Multiline = true;
            this.branchPhoneTextbox.Name = "branchPhoneTextbox";
            this.branchPhoneTextbox.Size = new System.Drawing.Size(259, 27);
            this.branchPhoneTextbox.TabIndex = 13;
            // 
            // branchPostalcodeTextbox
            // 
            this.branchPostalcodeTextbox.BackColor = System.Drawing.Color.Black;
            this.branchPostalcodeTextbox.ForeColor = System.Drawing.Color.White;
            this.branchPostalcodeTextbox.Location = new System.Drawing.Point(167, 215);
            this.branchPostalcodeTextbox.Multiline = true;
            this.branchPostalcodeTextbox.Name = "branchPostalcodeTextbox";
            this.branchPostalcodeTextbox.Size = new System.Drawing.Size(259, 27);
            this.branchPostalcodeTextbox.TabIndex = 12;
            // 
            // branchCountryTextbox
            // 
            this.branchCountryTextbox.BackColor = System.Drawing.Color.Black;
            this.branchCountryTextbox.ForeColor = System.Drawing.Color.White;
            this.branchCountryTextbox.Location = new System.Drawing.Point(167, 182);
            this.branchCountryTextbox.Multiline = true;
            this.branchCountryTextbox.Name = "branchCountryTextbox";
            this.branchCountryTextbox.Size = new System.Drawing.Size(259, 27);
            this.branchCountryTextbox.TabIndex = 11;
            // 
            // branchStateTextbox
            // 
            this.branchStateTextbox.BackColor = System.Drawing.Color.Black;
            this.branchStateTextbox.ForeColor = System.Drawing.Color.White;
            this.branchStateTextbox.Location = new System.Drawing.Point(167, 149);
            this.branchStateTextbox.Multiline = true;
            this.branchStateTextbox.Name = "branchStateTextbox";
            this.branchStateTextbox.Size = new System.Drawing.Size(259, 27);
            this.branchStateTextbox.TabIndex = 10;
            // 
            // branchCityTextbox
            // 
            this.branchCityTextbox.BackColor = System.Drawing.Color.Black;
            this.branchCityTextbox.ForeColor = System.Drawing.Color.White;
            this.branchCityTextbox.Location = new System.Drawing.Point(167, 116);
            this.branchCityTextbox.Multiline = true;
            this.branchCityTextbox.Name = "branchCityTextbox";
            this.branchCityTextbox.Size = new System.Drawing.Size(259, 27);
            this.branchCityTextbox.TabIndex = 9;
            // 
            // branchStreetTextbox
            // 
            this.branchStreetTextbox.BackColor = System.Drawing.Color.Black;
            this.branchStreetTextbox.ForeColor = System.Drawing.Color.White;
            this.branchStreetTextbox.Location = new System.Drawing.Point(167, 82);
            this.branchStreetTextbox.Multiline = true;
            this.branchStreetTextbox.Name = "branchStreetTextbox";
            this.branchStreetTextbox.Size = new System.Drawing.Size(259, 27);
            this.branchStreetTextbox.TabIndex = 8;
            // 
            // branchNameTextbox
            // 
            this.branchNameTextbox.BackColor = System.Drawing.Color.Black;
            this.branchNameTextbox.ForeColor = System.Drawing.Color.White;
            this.branchNameTextbox.Location = new System.Drawing.Point(167, 49);
            this.branchNameTextbox.Multiline = true;
            this.branchNameTextbox.Name = "branchNameTextbox";
            this.branchNameTextbox.Size = new System.Drawing.Size(259, 27);
            this.branchNameTextbox.TabIndex = 7;
            // 
            // branchstatelabel
            // 
            this.branchstatelabel.AutoSize = true;
            this.branchstatelabel.Location = new System.Drawing.Point(40, 152);
            this.branchstatelabel.Name = "branchstatelabel";
            this.branchstatelabel.Size = new System.Drawing.Size(48, 19);
            this.branchstatelabel.TabIndex = 6;
            this.branchstatelabel.Text = "State";
            // 
            // branchphonelabel
            // 
            this.branchphonelabel.AutoSize = true;
            this.branchphonelabel.Location = new System.Drawing.Point(40, 248);
            this.branchphonelabel.Name = "branchphonelabel";
            this.branchphonelabel.Size = new System.Drawing.Size(59, 19);
            this.branchphonelabel.TabIndex = 5;
            this.branchphonelabel.Text = "Phone";
            // 
            // branchpostalcodelabel
            // 
            this.branchpostalcodelabel.AutoSize = true;
            this.branchpostalcodelabel.Location = new System.Drawing.Point(40, 215);
            this.branchpostalcodelabel.Name = "branchpostalcodelabel";
            this.branchpostalcodelabel.Size = new System.Drawing.Size(102, 19);
            this.branchpostalcodelabel.TabIndex = 4;
            this.branchpostalcodelabel.Text = "Postal Code";
            // 
            // branchcountrylabel
            // 
            this.branchcountrylabel.AutoSize = true;
            this.branchcountrylabel.Location = new System.Drawing.Point(40, 182);
            this.branchcountrylabel.Name = "branchcountrylabel";
            this.branchcountrylabel.Size = new System.Drawing.Size(71, 19);
            this.branchcountrylabel.TabIndex = 3;
            this.branchcountrylabel.Text = "Country";
            this.branchcountrylabel.Click += new System.EventHandler(this.branchcountrylabel_Click);
            // 
            // branchcitylabel
            // 
            this.branchcitylabel.AutoSize = true;
            this.branchcitylabel.Location = new System.Drawing.Point(40, 116);
            this.branchcitylabel.Name = "branchcitylabel";
            this.branchcitylabel.Size = new System.Drawing.Size(39, 19);
            this.branchcitylabel.TabIndex = 2;
            this.branchcitylabel.Text = "City";
            // 
            // branchstreetlabel
            // 
            this.branchstreetlabel.AutoSize = true;
            this.branchstreetlabel.Location = new System.Drawing.Point(40, 82);
            this.branchstreetlabel.Name = "branchstreetlabel";
            this.branchstreetlabel.Size = new System.Drawing.Size(54, 19);
            this.branchstreetlabel.TabIndex = 1;
            this.branchstreetlabel.Text = "Street";
            // 
            // branchNamelabel
            // 
            this.branchNamelabel.AutoSize = true;
            this.branchNamelabel.Location = new System.Drawing.Point(40, 49);
            this.branchNamelabel.Name = "branchNamelabel";
            this.branchNamelabel.Size = new System.Drawing.Size(113, 19);
            this.branchNamelabel.TabIndex = 0;
            this.branchNamelabel.Text = "Branch Name";
            // 
            // querylabel
            // 
            this.querylabel.AutoSize = true;
            this.querylabel.Location = new System.Drawing.Point(308, 409);
            this.querylabel.Name = "querylabel";
            this.querylabel.Size = new System.Drawing.Size(0, 13);
            this.querylabel.TabIndex = 15;
            this.querylabel.UseWaitCursor = true;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Black;
            this.label1.Font = new System.Drawing.Font("Arial", 26.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(274, 29);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(323, 41);
            this.label1.TabIndex = 16;
            this.label1.Text = "Add A New Branch";
            // 
            // AddNewBranch
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Black;
            this.ClientSize = new System.Drawing.Size(800, 479);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.querylabel);
            this.Controls.Add(this.groupBox1);
            this.Name = "AddNewBranch";
            this.Text = "AddNewBranch";
            this.Load += new System.EventHandler(this.AddNewBranch_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label branchstatelabel;
        private System.Windows.Forms.Label branchphonelabel;
        private System.Windows.Forms.Label branchpostalcodelabel;
        private System.Windows.Forms.Label branchcountrylabel;
        private System.Windows.Forms.Label branchcitylabel;
        private System.Windows.Forms.Label branchstreetlabel;
        private System.Windows.Forms.Label branchNamelabel;
        private System.Windows.Forms.Button addBranchbutton;
        private System.Windows.Forms.TextBox branchPhoneTextbox;
        private System.Windows.Forms.TextBox branchPostalcodeTextbox;
        private System.Windows.Forms.TextBox branchCountryTextbox;
        private System.Windows.Forms.TextBox branchStateTextbox;
        private System.Windows.Forms.TextBox branchCityTextbox;
        private System.Windows.Forms.TextBox branchStreetTextbox;
        private System.Windows.Forms.TextBox branchNameTextbox;
        private System.Windows.Forms.Label querylabel;
        private System.Windows.Forms.Label label1;
    }
}